
<?php
include_once 'Operation.php';
?>
<?php
$stu = new Student();
?>

<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $attend = $_POST['attend'];
    $roll = $_POST['roll'];
    $name = $_POST['name'];
    $date = $_POST['date'];
    $insertattend = $stu->insertAttendance($roll, $name, $date, $attend);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $status = $_POST['txtprice'];
    $optn = $_POST['opt'];
    $roll = $_POST['roll'];
    /*
        print_r($optn);
        print_r($roll);
        print_r($status);*/
    $up = $stu->upd($roll, $optn, $status);
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Attendance</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
	 <style>
  nav{
	 background-image:url(img/register.jpg);
    background-size:     cover;                     
    background-repeat:   no-repeat;
    background-position: center center;   	 
	
}
</style>

</head>
<body>
	<header id="header" >
			<div class="container">

				<div class="navbar-header">
					<!-- Logo -->
				
					<!-- /Logo -->

					<!-- Mobile toggle -->
					<button class="navbar-toggle">
						<span></span>
					</button>
					<!-- /Mobile toggle -->
				</div>

				<!-- Navigation -->
				<nav id="nav">
					<ul class="main-menu nav navbar-nav navbar-right">
						<li><a href="../test_wih_session/index.php">Home</a></li>
						<li><a href="index.php">About</a></li>
						<li><a href="#">Courses</a></li>
						<li><a href="blog.php">Blog</a></li>
						<li><a href="contact.php">Contact</a></li>
                        <li><a href="logout.php">Logout</a></li>
					</ul>
				</nav>
				<!-- /Navigation -->

			</div>
		</header>
<div class="container">
    <form action="" method="post">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th scope="col">S.No</th>
                <th scope="col">Roll No</th>
                <th scope="col">Name</th>
                <th scope="col"><input type="date" id="date" name="date"></th>
                <th scope="col">Total Attendance</th>
                <th scope="col">Present/Permission</th>
                <th scope="col">Percentage</th>
                <th scope="col">
                    <select style="background-color: #8884" name="opt">
                        <option value="">choose</option>
                        <option value="permit">Permit</option>
                        <option value="not permit">Not Permit</option>
                        <option value="halt">Dfl</option>
                    </select></th>
                <th scope="col">Status</th>
            </tr>
            </thead>
            <tbody>

            <?php

            $get_student = $stu->getStudents();
            if ($get_student) {
                $i = 0;
                while ($row = $get_student->fetch_assoc()) {
                    $i++;

                    ?>

                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $row['roll']; ?>
                            <input type="hidden" value="<?php echo $row['roll']; ?>" name="roll[<?php echo $i; ?>]">
                        </td>
                        <td><?php echo $row['name']; ?>
                            <input type="hidden" value="<?php echo $row['name']; ?>" name="name[<?php echo $i; ?>]">
                        </td>
                        <td><input type="radio" name="attend[<?php echo $i; ?>]" value="present">P
                            <input type="radio" name="attend[<?php echo $i; ?>]" value="absent">A
                            <input type="radio" name="attend[<?php echo $i; ?>]" value="permission">PR
                        </td>
                        <td><?php echo $stu->tdate(); ?> </td>
                        <td><?php
                            $attendence = $stu->countAttendence($row['roll']);
                            echo($attendence->num_rows);
                            ?>
                        </td>
                        <td><?php
                            $b = $stu->tdate();
                            $a = $attendence->num_rows;
                            $c = ($a / $b) * 100;
                            if ($c < 50) {
                                ?> <span style="color: red"><?php echo $c; ?></span><?php
                            } elseif (($c < 70) && ($c > 50)) {
                                ?> <span style="color: blue"><?php echo $c; ?></span><?php
                            } else {
                                ?> <span style="color: green"><?php echo $c; ?></span><?php
                            }
                            ?>
                        </td>
                        <td>
                            <select name="cmbitems[<?php echo $i; ?>]" id="cmbitems[<?php echo $i; ?>]"
                                    onclick="cboItemsChanged(<?php echo $i; ?>)"
                                    onchange="cboItemsChanged(<?php echo $i; ?>)">
                                <option value="">choose</option>
                                <option value="Permit">permit</option>
                                <option value="Notpermit">Notpermit</option>
                                <option value="Halt">Halt</option>
                            </select>
                        </td>
                        <td><input type="text" name="txtprice[<?php echo $i; ?>]" id="txtprice[<?php echo $i; ?>]"
                                   value="<?php echo $row['status']; ?>">
                            <input type="hidden" value="<?php echo $cmbitems; ?>" name="status[<?php echo $i; ?>]"></td>
                    </tr>
                    <?php
                }

            }
            ?>
            </tbody>
        </table>

        <input type="submit" name="insert" class="btn btn-primary" value="Insert">
</div>
</form>
</div>

<script type="text/javascript">

    <!-- onload and onchange event -->
    function cboItemsChanged(i) {

        var select = document.getElementById('cmbitems[' + i + "]");
        var input = document.getElementById('txtprice[' + i + "]");
        // select.onchange = function () {
        input.value = select.value;
        // console.log("Triggered");
        // }
    }

</script>
<script type="text/javascript" href="jquery.min.js"></script>


</body>
</html>
