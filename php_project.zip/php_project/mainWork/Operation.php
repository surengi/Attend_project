<?php
include_once 'Database.php';
?>

<?php

class Student
{
    private $db;
// making connection to database
    public function __construct()
    {
        $this->db = new Database();
    }

// for selection the student from the database
    public function getStudents()
    {
        $query = "SELECT a.roll, a.name, a.attend_time, a.attend, b.status FROM attendance a, status b where a.roll = b.roll GROUP BY roll ";
        $result = $this->db->select($query);
        return $result;
    }
// counting the roll number according to the date value individually for present and permission
    public function countAttendence($roll)
    {
        $query = "SELECT * FROM `attendance` WHERE `roll`= '$roll' AND `attend`='present' OR 'permission' ";
        $result = $this->db->select($query);
        return $result;
    }
// counting the total number of class taken according to the date
     public function tdate()
    {
        $sql = "SELECT DISTINCT (attend_time)from attendance";
        $result = $this->db->select($sql);
        $num_rows = mysqli_num_rows($result);
        return "$num_rows";
    }

//Inserting the values
    public function insertAttendance($roll, $name, $date, $attend)
    {
        $count = sizeof($roll);
        for ($i = 1; $i <= $count; $i++) {
            $att = "INSERT INTO attendance(`roll`, `name`, `attend_time`, `attend`) VALUES ('$roll[$i]','$name[$i]','$date','$attend[$i]')";
            $res = $this->db->insert($att);
        }
        print_r("<script type='text/javascript'>alert('data inserted Succesfully');</script>");


    }
// inserting the status
    public function upd($roll, $optn, $status)
    {
        $count = sizeof($roll);
        if ($optn != '') {
            for ($i = 1; $i <= $count; $i++) {
                print_r($optn[$i]);
                $att = "UPDATE `status` SET `status`='$optn' WHERE roll='$roll[$i]'";
                $result = $this->db->update($att);

            }
        } else {
            for ($i = 1; $i <= $count; $i++) {
                $att = "UPDATE `status` SET `status`='$status[$i]' WHERE roll='$roll[$i]'";
                $result = $this->db->update($att);

            }
        }
    }
}

?>