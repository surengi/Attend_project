<?php
include("Cone.php");
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {
    // username and password sent from form

    $name = $_POST['name'];
    $roll = $_POST['roll'];

    $sql="INSERT INTO `status` (`name`, `roll`) VALUES ('$name', '$roll')";
    $result = mysqli_query($db,$sql);

    

    if($result) {
		echo "<script type='text/javascript'>alert('Successful!!')</script>";
			
    }else {
       echo"sorry";
    }
}
?>


<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="../js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


 
    <!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body{
	 background-image:url(./img/register.jpg);
    background-size:     cover;                     
    background-repeat:   no-repeat;
    background-position: center center;   	 
	
}
.form{
	color:white;
	background-color:#012641;
	width:500px;
	margin-top:30px;
}
h2{
	color:white;
}

  </style>
</head>
<body>
<div class="container form">
  <h2>Registration Form</h2>
  <form action="" method="post" style="width:400px float:center; " class="">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" placeholder="Name" name="name">
    </div>
    <div class="form-group">
      <label for="pwd">Roll:</label>
      <input type="text"  placeholder="Roll Number" name="roll">
    </div>
    <button type="submit" class="btn btn-info">Register</button>
	<a href="popupbox.php" class="pull-right btn btn-primary">Login</a>
	</form>
    </div>

</body>
</html>