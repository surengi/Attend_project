<?php
include("Config.php");
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {
    // username and password sent from form

    $myusername = mysqli_real_escape_string($db,$_POST['name']);
    $mypassword = mysqli_real_escape_string($db,$_POST['pass']);

    $sql = "SELECT id FROM tbl_admin WHERE name = '$myusername' and password = '$mypassword'";
    $result = mysqli_query($db,$sql);
    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
    $active = $row['active'];

    $count = mysqli_num_rows($result);

    // If result matched $myusername and $mypassword, table row must be 1 row

    if($count == 1) {
        $_SESSION['login_user'] = $myusername;

        header("location: index.php");
    }else {
        $error = "Your Login Name or Password is invalid";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <script src="mydialogexample.js"></script>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <br>
            <button class="btn btn-primary btn-sm pull-right" data-target="#loginmodal" data-toggle="modal">Login</button>
			<a href="register.php">Register</a>
			<br>
        	
        <!-- /Navigation -->

    </div>
</header>
<!-- Login Model popup box-->
            <div class="modal" id="loginmodal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">login</h4>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <div class="form-group">
                                    <label for="inputUserName">Username</label>
                                    <input class="form-control" name="name" placeholder="login UserName" type="text" id="inputUserName">
                                </div>
                                <div class="form-group">
                                    <label for="inputPassword">Password</label>
                                    <input class="form-control" name="pass" placeholder="login Password" type="password" id="inputpassword">
                                </div>
                                <button class="btn btn-primary" name="login">Login</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-primary" name="register"on_click><a href="register.php">Register</a> </button>
                                <button class="btn btn-primary" data-dismiss="modal">cancel</button>
                        </div>
                    </div>
                </div>
				
				
<!-- Login Model popup box-->



				
				
            </div>

        </div>
    </div>
</div>


<!-- /Header -->

<!-- Home -->
<div id="home" class="hero-area">

    <!-- Backgound Image -->
    <div class="bg-image bg-parallax overlay" style="background-image:url(./img/home-background.jpg)"></div>

    <!-- /Backgound Image -->


    <!-- Create a Carousel -->

    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner">

            <div class="item active">
                <img src="img/c3.jpg" alt="Los Angeles">
            </div>

            <div class="item">
                <img src="img/c3.jpg" alt="Los Angeles">
            </div>

            <div class="item">
                <img src="img/c3.jpg" alt="Los Angeles">
            </div>
        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </div>






<!-- this is the main content part>

<!-- jQuery Plugins -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
</body>

</html>
